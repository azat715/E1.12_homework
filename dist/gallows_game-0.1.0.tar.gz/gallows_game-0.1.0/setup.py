# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gallows_game']

package_data = \
{'': ['*']}

install_requires = \
['fire>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['gallows_game = gallows_game.main:cli']}

setup_kwargs = {
    'name': 'gallows-game',
    'version': '0.1.0',
    'description': 'игра виселица',
    'long_description': None,
    'author': 'azat715',
    'author_email': 'azat715@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
